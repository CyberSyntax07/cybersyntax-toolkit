# Tools

Place small, reusable developer utilities in this folder.

Examples:
- file helpers
- text utilities
- project maintenance tools
- local development helpers
