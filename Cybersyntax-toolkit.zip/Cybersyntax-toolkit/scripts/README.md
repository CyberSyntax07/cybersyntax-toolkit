# Scripts

Place reusable project scripts here.

Keep scripts documented and safe to run, and avoid committing secrets such as API keys or passwords.
